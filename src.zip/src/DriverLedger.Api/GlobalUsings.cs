﻿global using System.Security.Claims;
global using Microsoft.EntityFrameworkCore;
global using DriverLedger.Domain.Receipts;
global using DriverLedger.Domain.Files;
global using DriverLedger.Infrastructure.Persistence;
