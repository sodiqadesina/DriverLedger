namespace DriverLedger.Domain.Statements
{
    public sealed class StatementLine : Entity, ITenantScoped
    {
        public Guid TenantId { get; set; }
        public Guid StatementId { get; set; }

        public Statement Statement { get; set; } = default!;

        public DateOnly LineDate { get; set; }

        public required string LineType { get; set; } // Income, Fee, Tax, Metric, Expense...
        public string? Description { get; set; }

        // Existing (kept for now to avoid breaking callers)
        public string? Currency { get; set; }

        // Legacy amount (kept temporarily)
        public decimal Amount { get; set; }

        // NEW: Monetary vs Metric split
        public bool IsMetric { get; set; }

        // NEW: Money for Income/Fee/Expense only; null for Metric lines
        public decimal? MoneyAmount { get; set; }

        // NEW: Metric data for non-posting lines (e.g., RideKilometers)
        public decimal? MetricValue { get; set; }
        public string? MetricKey { get; set; } // RideKilometers, RideMiles, Trips, ...
        public string? Unit { get; set; } // km, mi, trips, ...

        // NEW: Normalized currency + evidence
        public string? CurrencyCode { get; set; } // ISO: CAD, USD, ...
        public string CurrencyEvidence { get; set; } = "Inferred"; // Extracted | Inferred

        // NEW: Classification evidence (line type / category)
        public string ClassificationEvidence { get; set; } = "Inferred"; // Extracted | Inferred

        public decimal? TaxAmount { get; set; }
    }
}
