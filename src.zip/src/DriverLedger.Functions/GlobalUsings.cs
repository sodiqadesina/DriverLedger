﻿global using Microsoft.Azure.Functions.Worker;
global using Microsoft.Extensions.Logging;
