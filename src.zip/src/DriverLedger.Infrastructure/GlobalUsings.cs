﻿global using Microsoft.EntityFrameworkCore;
