﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DriverLedger.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class AddStatementMetricsAndCurrencyEvidence : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "CurrencyCode",
                table: "Statements",
                type: "nvarchar(3)",
                maxLength: 3,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "CurrencyEvidence",
                table: "Statements",
                type: "nvarchar(20)",
                maxLength: 20,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "ClassificationEvidence",
                table: "StatementLines",
                type: "nvarchar(20)",
                maxLength: 20,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "CurrencyCode",
                table: "StatementLines",
                type: "nvarchar(3)",
                maxLength: 3,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "CurrencyEvidence",
                table: "StatementLines",
                type: "nvarchar(20)",
                maxLength: 20,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<bool>(
                name: "IsMetric",
                table: "StatementLines",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<string>(
                name: "MetricKey",
                table: "StatementLines",
                type: "nvarchar(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<decimal>(
                name: "MetricValue",
                table: "StatementLines",
                type: "decimal(18,4)",
                precision: 18,
                scale: 4,
                nullable: true);

            migrationBuilder.AddColumn<decimal>(
                name: "MoneyAmount",
                table: "StatementLines",
                type: "decimal(18,2)",
                precision: 18,
                scale: 2,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Unit",
                table: "StatementLines",
                type: "nvarchar(16)",
                maxLength: 16,
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "CurrencyCode",
                table: "Statements");

            migrationBuilder.DropColumn(
                name: "CurrencyEvidence",
                table: "Statements");

            migrationBuilder.DropColumn(
                name: "ClassificationEvidence",
                table: "StatementLines");

            migrationBuilder.DropColumn(
                name: "CurrencyCode",
                table: "StatementLines");

            migrationBuilder.DropColumn(
                name: "CurrencyEvidence",
                table: "StatementLines");

            migrationBuilder.DropColumn(
                name: "IsMetric",
                table: "StatementLines");

            migrationBuilder.DropColumn(
                name: "MetricKey",
                table: "StatementLines");

            migrationBuilder.DropColumn(
                name: "MetricValue",
                table: "StatementLines");

            migrationBuilder.DropColumn(
                name: "MoneyAmount",
                table: "StatementLines");

            migrationBuilder.DropColumn(
                name: "Unit",
                table: "StatementLines");
        }
    }
}
