using System.Globalization;
using System.Text.RegularExpressions;

namespace DriverLedger.Infrastructure.Statements.Extraction;

internal static class LyftStatementTextFallback
{
    // Lyft PDFs often lay out like:
    //   <Label>
    //   <Amount>
    // or
    //   <Label>  <Amount>
    //
    // This fallback is INTENTIONALLY “Lyft-specific” and “label-driven” so it doesn’t
    // accidentally pick up random numbers from the page.

    public static List<StatementLineNormalized> TryExtract(string analyzedContent)
    {
        if (string.IsNullOrWhiteSpace(analyzedContent))
            return new List<StatementLineNormalized>();

        // Provider check
        if (!Regex.IsMatch(analyzedContent, @"\bLyft\b", RegexOptions.IgnoreCase))
            return new List<StatementLineNormalized>();

        var lines = analyzedContent
            .Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

        var results = new List<StatementLineNormalized>();

        // ===== Metrics =====
        AddRideDistanceMetric();
        AddTotalRidesMetric(); //  Total Rides is a metric (NOT income)

        // ===== Income (money) =====
        AddMoneyLine("Income", "Gross fares", @"\bGross\s+fares\b");
        AddMoneyLine("Income", "Bonuses", @"\bBonuses\b");
        AddMoneyLine("Income", "Tips", @"\bTips\b(?!.*GST)(?!.*HST)");

        // ===== Fees (money) =====
        // F Lyft always has “Lyft & 3rd party fees” as the real value we want.
        // Do NOT also add a generic “3rd party fees” line if it’s the same number.
        AddMoneyLine("Fee", "Lyft & 3rd party fees", @"\bLyft\s*&\s*3rd\s+party\s+fees\b");

        // Optional: “Tolls ...” lines
        AddMoneyLine("Fee", "Tolls", @"\bTolls\b");

        // ===== Tax Collected (tax-only) =====
        // Store in MoneyAmount (NOT TaxAmount) – restores your old behavior.
        AddTaxOnlyMoney("TaxCollected", "GST/HST received from passengers",
            @"\bGST\s*/\s*HST\s+received\s+from\s+passengers\b");

        AddTaxOnlyMoney("TaxCollected", "GST/HST received on bonuses",
            @"\bGST\s*/\s*HST\s+received\s+on\s+bonuses\b");

        // ===== ITC (tax-only) =====
        //  Store in MoneyAmount (NOT TaxAmount) – restores your old behavior.
        AddTaxOnlyMoney("Itc", "GST/HST paid on Lyft and 3rd party fees",
            @"\bGST\s*/\s*HST\s+paid\s+on\s+Lyft\s+and\s+3rd\s+party\s+fees\b");

        // Only return if meaningful
        var anyNonZero = results.Any(x =>
            (x.MoneyAmount.HasValue && x.MoneyAmount.Value != 0m) ||
            (x.IsMetric && x.MetricValue.HasValue && x.MetricValue.Value != 0m));

        return anyNonZero ? results : new List<StatementLineNormalized>();

        // ---------------- local helpers ----------------

        void AddRideDistanceMetric()
        {
            foreach (var l in lines)
            {
                if (!StatementExtractionParsing.TryParseRideDistanceMetric(l, out var key, out var value, out var unit))
                    continue;

                results.Add(new StatementLineNormalized(
                    LineDate: DateOnly.MinValue,
                    LineType: "Metric",
                    Description: "Ride distance (Lyft statement)",
                    CurrencyCode: "CAD",
                    CurrencyEvidence: "Inferred",
                    ClassificationEvidence: "Extracted",
                    IsMetric: true,
                    MetricKey: key,
                    MetricValue: value,
                    Unit: unit,
                    MoneyAmount: null,
                    TaxAmount: null
                ));

                return; // keep first confident match
            }
        }

        void AddTotalRidesMetric()
        {
            var rides = FindIntNearLabel(lines, @"\bTotal\s+Rides\b", lookAhead: 6);
            if (!rides.HasValue) return;

            results.Add(new StatementLineNormalized(
                LineDate: DateOnly.MinValue,
                LineType: "Metric",
                Description: "Total Rides",
                CurrencyCode: "CAD",
                CurrencyEvidence: "Inferred",
                ClassificationEvidence: "Extracted",
                IsMetric: true,
                MetricKey: "Trips",
                MetricValue: rides.Value,
                Unit: "trips",
                MoneyAmount: null,
                TaxAmount: null
            ));
        }

        void AddMoneyLine(string lineType, string desc, string labelPattern)
        {
            // If this label is “Total Rides”, don’t treat as money (guard)
            if (Regex.IsMatch(desc, @"\bTotal\s+Rides\b", RegexOptions.IgnoreCase)) return;

            var amt = FindMoneyNearLabel(lines, labelPattern, lookAhead: 6);
            if (!amt.HasValue) return;

            results.Add(new StatementLineNormalized(
                LineDate: DateOnly.MinValue,
                LineType: lineType,
                Description: desc,

                IsMetric: false,
                MoneyAmount: Math.Abs(amt.Value),
                MetricValue: null,
                MetricKey: null,
                Unit: null,

                CurrencyCode: "CAD",
                CurrencyEvidence: "Extracted",
                ClassificationEvidence: "Extracted",

                TaxAmount: null
            ));
        }

        void AddTaxOnlyMoney(string lineType, string desc, string labelPattern)
        {
            var amt = FindMoneyNearLabel(lines, labelPattern, lookAhead: 6);
            if (!amt.HasValue) return;

            results.Add(new StatementLineNormalized(
                LineDate: DateOnly.MinValue,
                LineType: lineType,
                Description: desc,

                IsMetric: false,

                //  store tax-only amount in MoneyAmount (old behavior)
                MoneyAmount: Math.Abs(amt.Value),

                MetricValue: null,
                MetricKey: null,
                Unit: null,

                CurrencyCode: "CAD",
                CurrencyEvidence: "Extracted",
                ClassificationEvidence: "Extracted",

                // keep null so header totals & posting logic can use MoneyAmount
                TaxAmount: null
            ));
        }
    }

    // ---------------- parsing helpers ----------------

    // Money: we only trust values that look like money (2 decimals),
    // which prevents “104558”, “792383085RP0001”, etc.
    private static readonly Regex MoneyRegex =
        new(@"(?<!\d)(\d{1,3}(?:[,\s]\d{3})*(?:\.\d{2})|\d+\.\d{2})(?!\d)",
            RegexOptions.Compiled);

    private static decimal? FindMoneyNearLabel(IReadOnlyList<string> src, string labelPattern, int lookAhead = 4)
    {
        for (var i = 0; i < src.Count; i++)
        {
            var line = src[i];

            if (!Regex.IsMatch(line, labelPattern, RegexOptions.IgnoreCase))
                continue;

            // 1) same line
            {
                var m = MoneyRegex.Match(line);
                if (m.Success)
                {
                    var amt = StatementExtractionParsing.ParseAmount(m.Value);
                    if (amt.HasValue) return amt.Value;
                }
            }

            // 2) next lines
            for (var j = 1; j <= lookAhead && (i + j) < src.Count; j++)
            {
                var next = src[i + j];

                var m = MoneyRegex.Match(next);
                if (!m.Success) continue;

                var amt = StatementExtractionParsing.ParseAmount(m.Value);
                if (amt.HasValue) return amt.Value;
            }

            return null;
        }

        return null;
    }

    // Total Rides is typically an integer. We treat it as a metric and never as money.
    private static readonly Regex IntRegex =
        new(@"(?<!\d)(\d{1,6})(?!\d)", RegexOptions.Compiled);

    private static decimal? FindIntNearLabel(IReadOnlyList<string> src, string labelPattern, int lookAhead = 4)
    {
        for (var i = 0; i < src.Count; i++)
        {
            var line = src[i];

            if (!Regex.IsMatch(line, labelPattern, RegexOptions.IgnoreCase))
                continue;

            // same line
            {
                var m = IntRegex.Match(line);
                if (m.Success && decimal.TryParse(m.Value, NumberStyles.Number, CultureInfo.InvariantCulture, out var v))
                    return v;
            }

            // next lines
            for (var j = 1; j <= lookAhead && (i + j) < src.Count; j++)
            {
                var next = src[i + j];
                var m = IntRegex.Match(next);
                if (!m.Success) continue;

                if (decimal.TryParse(m.Value, NumberStyles.Number, CultureInfo.InvariantCulture, out var v))
                    return v;
            }

            return null;
        }

        return null;
    }
}
