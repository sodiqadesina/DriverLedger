using System.Text.RegularExpressions;

namespace DriverLedger.Infrastructure.Statements.Extraction;

internal static class LyftStatementTextFallback
{
    public static List<StatementLineNormalized> TryExtract(string analyzedContent)
    {
        if (string.IsNullOrWhiteSpace(analyzedContent))
            return new List<StatementLineNormalized>();

        // Provider check
        if (!Regex.IsMatch(analyzedContent, @"\bLyft\b", RegexOptions.IgnoreCase))
            return new List<StatementLineNormalized>();

        var lines = analyzedContent
            .Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

        var results = new List<StatementLineNormalized>();

        // Finds the first numeric value on a matching line.
        static decimal? FindAmount(IEnumerable<string> src, string labelPattern)
        {
            foreach (var l in src)
            {
                if (!Regex.IsMatch(l, labelPattern, RegexOptions.IgnoreCase))
                    continue;

                var amt = StatementExtractionParsing.ParseAmount(l);
                if (amt.HasValue) return amt.Value;
            }
            return null;
        }

        // ---- Metrics: Ride Kilometers ----
        // Lyft statements vary; we look for common phrases.
        AddRideKilometersMetric(
            desc: "Ride kilometers",
            labelPattern: @"\b(ride|trip|total)\s*(kilometers|kilometres|kms|km)\b|\btotal\s*km\b");

        // If miles exist, convert to km and store RideKilometers
        AddMilesAsKilometersMetric(
            desc: "Ride miles (converted to km)",
            labelPattern: @"\b(ride|trip|total)\s*(miles|mi)\b|\btotal\s*miles\b");

        // ---- Income (not including GST/HST) ----
        AddIncome("Gross fares", @"\bGross\s+fares\b");
        AddIncome("Bonuses", @"\bBonuses\b");
        AddIncome("Tips", @"\bTips\b(?!.*GST)");

        // ---- Fees ----
        AddFee("Lyft & 3rd party fees", @"\bLyft\s*&\s*3rd\s+party\s+fees\b");

        // ---- Tax collected (you remit) ----
        AddTaxCollected("GST/HST received from passengers", @"\bGST\s*/\s*HST\s+received\s+from\s+passengers\b");
        AddTaxCollected("GST/HST received on bonuses", @"\bGST\s*/\s*HST\s+received\s+on\s+bonuses\b");

        // ---- ITC ----
        AddItc("GST/HST paid on Lyft and 3rd party fees", @"\bGST\s*/\s*HST\s+paid\s+on\s+Lyft\s+and\s+3rd\s+party\s+fees\b");

        // Only return if we found meaningful amounts
        var anyNonZero = results.Any(x =>
            (x.MoneyAmount.HasValue && x.MoneyAmount.Value != 0m) ||
            (x.TaxAmount.HasValue && x.TaxAmount.Value != 0m) ||
            (x.IsMetric && x.MetricValue.HasValue && x.MetricValue.Value != 0m));

        return anyNonZero ? results : new List<StatementLineNormalized>();

        // ---- local helpers ----

        void AddIncome(string desc, string labelPattern)
        {
            var amt = FindAmount(lines, labelPattern);
            if (!amt.HasValue) return;

            results.Add(new StatementLineNormalized(
                LineDate: DateOnly.MinValue,
                LineType: "Income",
                Description: desc,

                IsMetric: false,
                MoneyAmount: Math.Abs(amt.Value),
                MetricValue: null,
                MetricKey: null,
                Unit: null,

                CurrencyCode: "CAD",
                CurrencyEvidence: "Extracted",
                ClassificationEvidence: "Extracted",

                TaxAmount: null
            ));
        }

        void AddFee(string desc, string labelPattern)
        {
            var amt = FindAmount(lines, labelPattern);
            if (!amt.HasValue) return;

            results.Add(new StatementLineNormalized(
                LineDate: DateOnly.MinValue,
                LineType: "Fee",
                Description: desc,

                IsMetric: false,
                MoneyAmount: Math.Abs(amt.Value),
                MetricValue: null,
                MetricKey: null,
                Unit: null,

                CurrencyCode: "CAD",
                CurrencyEvidence: "Extracted",
                ClassificationEvidence: "Extracted",

                TaxAmount: null
            ));
        }

        void AddTaxCollected(string desc, string labelPattern)
        {
            var amt = FindAmount(lines, labelPattern);
            if (!amt.HasValue) return;

            results.Add(new StatementLineNormalized(
                LineDate: DateOnly.MinValue,
                LineType: "TaxCollected",
                Description: desc,

                IsMetric: false,
                MoneyAmount: 0m,
                MetricValue: null,
                MetricKey: null,
                Unit: null,

                CurrencyCode: "CAD",
                CurrencyEvidence: "Extracted",
                ClassificationEvidence: "Extracted",

                TaxAmount: Math.Abs(amt.Value)
            ));
        }

        void AddItc(string desc, string labelPattern)
        {
            var amt = FindAmount(lines, labelPattern);
            if (!amt.HasValue) return;

            results.Add(new StatementLineNormalized(
                LineDate: DateOnly.MinValue,
                LineType: "Itc",
                Description: desc,

                IsMetric: false,
                MoneyAmount: 0m,
                MetricValue: null,
                MetricKey: null,
                Unit: null,

                CurrencyCode: "CAD",
                CurrencyEvidence: "Extracted",
                ClassificationEvidence: "Extracted",

                TaxAmount: Math.Abs(amt.Value)
            ));
        }

        void AddRideKilometersMetric(string desc, string labelPattern)
        {
            var v = FindAmount(lines, labelPattern);
            if (!v.HasValue) return;

            results.Add(new StatementLineNormalized(
                LineDate: DateOnly.MinValue,
                LineType: "Metric",
                Description: desc,

                IsMetric: true,
                MoneyAmount: null,
                MetricValue: Math.Abs(v.Value),
                MetricKey: "RideKilometers",
                Unit: "km",

                CurrencyCode: null,
                CurrencyEvidence: "N/A",
                ClassificationEvidence: "Extracted",

                TaxAmount: null
            ));
        }

        void AddMilesAsKilometersMetric(string desc, string labelPattern)
        {
            var miles = FindAmount(lines, labelPattern);
            if (!miles.HasValue) return;

            var km = Math.Abs(miles.Value) * 1.609344m;

            results.Add(new StatementLineNormalized(
                LineDate: DateOnly.MinValue,
                LineType: "Metric",
                Description: desc,

                IsMetric: true,
                MoneyAmount: null,
                MetricValue: km,
                MetricKey: "RideKilometers",
                Unit: "km",

                CurrencyCode: null,
                CurrencyEvidence: "N/A",
                ClassificationEvidence: "Extracted",

                TaxAmount: null
            ));
        }
    }
}
