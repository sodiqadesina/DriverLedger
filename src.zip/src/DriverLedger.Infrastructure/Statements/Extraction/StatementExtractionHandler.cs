using DriverLedger.Application.Common;
using DriverLedger.Application.Messaging;
using DriverLedger.Application.Statements.Messages;
using DriverLedger.Domain.Auditing;
using DriverLedger.Domain.Files;
using DriverLedger.Domain.Notifications;
using DriverLedger.Domain.Statements;
using DriverLedger.Infrastructure.Files;
using DriverLedger.Infrastructure.Messaging;
using DriverLedger.Infrastructure.Persistence;
using Microsoft.Extensions.Logging;
using System.Text.Json;


namespace DriverLedger.Infrastructure.Statements.Extraction
{
    public sealed class StatementExtractionHandler(
        DriverLedgerDbContext db,
        ITenantProvider tenantProvider,
        IBlobStorage blobStorage,
        IEnumerable<IStatementExtractor> extractors,
        IMessagePublisher publisher,
        ILogger<StatementExtractionHandler> logger)
    {
        private static readonly JsonSerializerOptions JsonOpts = new(JsonSerializerDefaults.Web);

        public async Task HandleAsync(MessageEnvelope<StatementReceived> envelope, CancellationToken ct)
        {
            var tenantId = envelope.TenantId;
            var correlationId = envelope.CorrelationId;
            var msg = envelope.Data;

            tenantProvider.SetTenant(tenantId);

            using var scope = logger.BeginScope(new Dictionary<string, object?>
            {
                ["tenantId"] = tenantId,
                ["correlationId"] = correlationId,
                ["messageId"] = envelope.MessageId,
                ["fileObjectId"] = msg.FileObjectId,
                ["provider"] = msg.Provider,
                ["periodKey"] = msg.PeriodKey
            });

            // Load file metadata
            var file = await db.FileObjects.SingleAsync(x => x.TenantId == tenantId && x.Id == msg.FileObjectId, ct);

            // Choose extractor by content type
            var extractor = extractors.FirstOrDefault(x => x.CanHandleContentType(file.ContentType));
            if (extractor is null)
                throw new InvalidOperationException($"No statement extractor found for content type: {file.ContentType}");

            // Open blob stream
            await using var content = await blobStorage.OpenReadAsync(file.BlobPath, ct);

            // Extract normalized lines
            var normalized = await extractor.ExtractAsync(content, ct);

            // --- Debug: dump raw normalized items so we can inspect why descriptions differ
            if (logger.IsEnabled(LogLevel.Debug))
            {
                try
                {
                    logger.LogDebug("Raw normalized lines before collapse: {lines}", JsonSerializer.Serialize(normalized, JsonOpts));
                }
                catch
                {
                    // swallow logging serialization errors to avoid interfering with production flow
                }
            }

            // --------------------
            // Robust collapse:
            // - Separate metrics vs monetary rows
            // - Canonicalize/infer metric key + unit if missing
            // - Normalize metric value per-key (Trips => 0 dec, km => 2 dec)
            // - Normalize money/tax columns BEFORE grouping (important)
            // - Group metrics by canonical (MetricKey, MetricValue, Unit)
            // - Group monetary rows by (LineType, rounded Money, rounded Tax) but for tax-only prefer TaxAmount-based grouping
            // - Prefer ClassificationEvidence == "Extracted", then CurrencyEvidence == "Extracted"
            // --------------------

            static (string? MetricKey, string? Unit) InferMetricKeyAndUnit(string? description)
            {
                if (string.IsNullOrWhiteSpace(description)) return (null, null);
                var desc = description.Trim().ToLowerInvariant();

                if (desc.Contains("total rides") || (desc.Contains("rides") && desc.Contains("total")))
                    return ("Trips", "trips");

                if (desc.Contains("trip") && (desc.Contains("count") || desc.Contains("total")))
                    return ("Trips", "trips");

                if (desc.Contains("kilomet") || desc.Contains(" km"))
                    return ("RideKilometers", "km");

                if (desc.Contains(" mile") || desc.Contains(" mi"))
                    return ("RideMiles", "mi");

                if (desc.Contains("online hour") || desc.Contains("hours online") || desc.Contains("online time"))
                    return ("OnlineHours", "hours");

                return (null, null);
            }

            static decimal? NormalizeMetricValueForKey(string? metricKey, decimal? value)
            {
                if (!value.HasValue) return null;

                // per-key precision
                if (string.Equals(metricKey, "Trips", StringComparison.OrdinalIgnoreCase))
                    return decimal.Round(value.Value, 0, MidpointRounding.AwayFromZero);

                if (string.Equals(metricKey, "RideKilometers", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(metricKey, "RideMiles", StringComparison.OrdinalIgnoreCase))
                    return decimal.Round(value.Value, 2, MidpointRounding.AwayFromZero);

                if (string.Equals(metricKey, "OnlineHours", StringComparison.OrdinalIgnoreCase))
                    return decimal.Round(value.Value, 2, MidpointRounding.AwayFromZero);

                // fallback: 3 decimals
                return decimal.Round(value.Value, 3, MidpointRounding.AwayFromZero);
            }

            static string CanonicalMetricKey(string? raw)
            {
                if (string.IsNullOrWhiteSpace(raw)) return string.Empty;
                var key = raw.Trim().ToLowerInvariant();
                return key switch
                {
                    "trips" => "Trips",
                    "ridekilometers" => "RideKilometers",
                    "ridemiles" => "RideMiles",
                    "onlinehours" => "OnlineHours",
                    _ => char.ToUpperInvariant(key[0]) + key.Substring(1)
                };
            }

            static string CanonicalMetricDescription(string? metricKey)
            {
                if (string.IsNullOrWhiteSpace(metricKey)) return metricKey ?? string.Empty;
                return metricKey switch
                {
                    "Trips" => "Total Rides",
                    "RideKilometers" => "Ride distance",
                    "RideMiles" => "Ride distance",
                    "OnlineHours" => "Online hours",
                    _ => metricKey
                };
            }

            // PREPARE: canonicalize metric key/value and normalize money/tax into canonical columns for grouping
            var prepared = normalized
                .Select(x =>
                {
                    // start with extractor-provided metric key/unit
                    var key = x.MetricKey?.Trim();
                    var unit = x.Unit?.Trim();

                    // if missing metric key but marked metric, infer from description
                    if (string.IsNullOrWhiteSpace(key) && x.IsMetric)
                    {
                        var inferred = InferMetricKeyAndUnit(x.Description);
                        if (!string.IsNullOrWhiteSpace(inferred.MetricKey))
                        {
                            key = inferred.MetricKey;
                            unit = inferred.Unit;
                        }
                    }

                    // normalize metric value based on key
                    decimal? normMetricValue = null;
                    if (x.MetricValue.HasValue)
                        normMetricValue = NormalizeMetricValueForKey(key, x.MetricValue);

                    // NORMALIZE money/tax to canonical representation BEFORE grouping
                    var (canonMoney, canonTax) = StatementExtractionParsing.NormalizeTaxColumns(
                        resolvedLineType: x.LineType,
                        moneyAmount: x.MoneyAmount,
                        taxAmount: x.TaxAmount);

                    // Round canonical money/tax for stable grouping keys (2 decimals)
                    decimal? moneyGroup = canonMoney.HasValue ? decimal.Round(canonMoney.Value, 2, MidpointRounding.AwayFromZero) : null;
                    decimal? taxGroup = canonTax.HasValue ? decimal.Round(canonTax.Value, 2, MidpointRounding.AwayFromZero) : null;

                    return (Orig: x, MetricKeyNorm: key, MetricValueNorm: normMetricValue, UnitNorm: unit, MoneyNorm: moneyGroup, TaxNorm: taxGroup, CanonMoney: canonMoney, CanonTax: canonTax);
                })
                .ToList();

            // COLLAPSE: group by semantic identity using canonical money/tax (not raw extracted cells)
            var collapsed = prepared
                .GroupBy(t => (
                    LineType: t.Orig.LineType,
                    IsMetric: t.Orig.IsMetric,
                    Money: t.MoneyNorm,
                    Tax: t.TaxNorm,
                    MetricKey: (t.MetricKeyNorm ?? string.Empty).ToLowerInvariant(),
                    MetricValue: t.MetricValueNorm,
                    Unit: (t.UnitNorm ?? string.Empty).ToLowerInvariant(),
                    Currency: t.Orig.CurrencyCode))
                .Select(g =>
                {
                    // prefer extracted classification, then extracted currency, else first
                    var best = g
                        .OrderByDescending(x => string.Equals(x.Orig.ClassificationEvidence, "Extracted", StringComparison.OrdinalIgnoreCase) ? 1 : 0)
                        .ThenByDescending(x => string.Equals(x.Orig.CurrencyEvidence, "Extracted", StringComparison.OrdinalIgnoreCase) ? 1 : 0)
                        .First();

                    var groupKey = g.Key;
                    var canonicalMetricKey = string.IsNullOrWhiteSpace(groupKey.MetricKey) ? null : CanonicalMetricKey(groupKey.MetricKey);
                    var canonicalUnit = string.IsNullOrWhiteSpace(groupKey.Unit) ? null : groupKey.Unit;
                    var canonicalMetricValue = groupKey.MetricValue;

                    // Use canonical money/tax values (take first non-null CanonMoney/CanonTax from group)
                    decimal? chosenMoney = g.Select(x => x.CanonMoney).FirstOrDefault(v => v.HasValue);
                    decimal? chosenTax = g.Select(x => x.CanonTax).FirstOrDefault(v => v.HasValue);

                    // Choose the best description (prefer extracted), but map to a canonical human label for metrics
                    var chosenDesc = g.Select(x => x.Orig.Description)
                                      .Where(d => !string.IsNullOrWhiteSpace(d))
                                      .OrderByDescending(d => g.FirstOrDefault(y => y.Orig.Description == d)!.Orig.ClassificationEvidence == "Extracted" ? 1 : 0)
                                      .FirstOrDefault() ?? best.Orig.Description;

                    if (!string.IsNullOrWhiteSpace(canonicalMetricKey))
                    {
                        // force a tidy canonical metric description (removes numeric suffixes like "Total Rides 467")
                        chosenDesc = CanonicalMetricDescription(canonicalMetricKey);
                    }

                    return new StatementLineNormalized(
                        LineDate: best.Orig.LineDate,
                        LineType: best.Orig.LineType,
                        Description: chosenDesc,
                        CurrencyCode: best.Orig.CurrencyCode,
                        CurrencyEvidence: best.Orig.CurrencyEvidence,
                        ClassificationEvidence: best.Orig.ClassificationEvidence,
                        IsMetric: best.Orig.IsMetric,
                        MetricKey: canonicalMetricKey,
                        MetricValue: canonicalMetricValue,
                        Unit: canonicalUnit,
                        // Persist canonical money/tax (normalized) not raw Best.Orig
                        MoneyAmount: chosenMoney.HasValue ? Math.Abs(chosenMoney.Value) : (decimal?)null,
                        TaxAmount: chosenTax.HasValue ? Math.Abs(chosenTax.Value) : (decimal?)null
                    );
                })
                .ToList();

            // PRUNE: drop Income "bonus"/"bonuses" that exactly duplicate a Fee/Expense money amount
            var feeAmountSet = collapsed
                .Where(x => !x.IsMetric &&
                            (string.Equals(x.LineType, "Fee", StringComparison.OrdinalIgnoreCase) ||
                             string.Equals(x.LineType, "Expense", StringComparison.OrdinalIgnoreCase)))
                .Where(x => x.MoneyAmount.HasValue)
                .Select(x => decimal.Round(x.MoneyAmount!.Value, 2, MidpointRounding.AwayFromZero))
                .ToHashSet();

            // If no Lyft-fee-specific row exists, do not apply the aggressive prune.
            var pruned = collapsed.Where(x =>
            {
                if (!string.Equals(x.LineType, "Income", StringComparison.OrdinalIgnoreCase))
                    return true;

                if (!x.MoneyAmount.HasValue)
                    return true;

                // Only consider pruning if we found at least one Lyft fees amount to compare against.
                if (!feeAmountSet.Any())
                    return true;

                var amt = decimal.Round(x.MoneyAmount.Value, 2, MidpointRounding.AwayFromZero);
                if (!feeAmountSet.Contains(amt))
                    return true;

                // if the Income description looks like a bonus, and amount matches Lyft fee, prune it
                var desc = x.Description ?? string.Empty;
                if (desc.IndexOf("bonus", StringComparison.OrdinalIgnoreCase) >= 0)
                    return false; // prune

                return true;
            }).ToList();

            if (pruned.Count != collapsed.Count)
            {
                logger.LogInformation(
                    "Pruned {Dropped} suspect Income lines that duplicated Lyft & 3rd party fees for provider={Provider} periodKey={PeriodKey}",
                    collapsed.Count - pruned.Count, msg.Provider, msg.PeriodKey);
            }

            // Determine statement-level currency (once) from pruned set
            var resolvedStatementCurrency = ResolveStatementCurrency(file, pruned, out var stmtCurrencyEvidence);

            // Upsert statement (by Provider/PeriodType/PeriodKey unique index)
            var statement = await db.Statements.SingleOrDefaultAsync(x =>
                x.TenantId == tenantId &&
                x.Provider == msg.Provider &&
                x.PeriodType == msg.PeriodType &&
                x.PeriodKey == msg.PeriodKey, ct);

            if (statement is null)
            {
                statement = new Statement
                {
                    TenantId = tenantId,
                    FileObjectId = msg.FileObjectId,
                    Provider = msg.Provider,
                    PeriodType = msg.PeriodType,
                    PeriodKey = msg.PeriodKey,
                    PeriodStart = msg.PeriodStart,
                    PeriodEnd = msg.PeriodEnd,
                    VendorName = msg.Provider,
                    Status = "Draft",
                    CreatedAt = DateTimeOffset.UtcNow
                };
                db.Statements.Add(statement);
            }
            else
            {
                // update file link + period boundaries if reprocessing
                statement.FileObjectId = msg.FileObjectId;
                statement.PeriodStart = msg.PeriodStart;
                statement.PeriodEnd = msg.PeriodEnd;
                statement.Status = "Draft";
            }

            statement.CurrencyCode = resolvedStatementCurrency;
            statement.CurrencyEvidence = stmtCurrencyEvidence;

            // Replace existing lines for idempotency
            var existingLines = await db.StatementLines
                .Where(x => x.TenantId == tenantId && x.StatementId == statement.Id)
                .ToListAsync(ct);

            db.StatementLines.RemoveRange(existingLines);

            // Persist normalized -> domain
            var createdLines = new List<StatementLine>(capacity: pruned.Count);

            // helper: compare an existing persisted StatementLine with a normalized candidate
            static bool EquivalentMetricValue(decimal? a, decimal? b, string? metricKey)
            {
                if (!a.HasValue && !b.HasValue) return true;
                if (!a.HasValue || !b.HasValue) return false;

                var prec = string.Equals(metricKey, "Trips", StringComparison.OrdinalIgnoreCase) ? 0 : 2;
                return decimal.Round(a.Value, prec, MidpointRounding.AwayFromZero) ==
                       decimal.Round(b.Value, prec, MidpointRounding.AwayFromZero);
            }

            static bool IsEquivalent(StatementLine existing, StatementLineNormalized cand)
            {
                if (existing.IsMetric && cand.IsMetric)
                {
                    var k1 = existing.MetricKey?.Trim().ToLowerInvariant();
                    var k2 = cand.MetricKey?.Trim().ToLowerInvariant();
                    if (k1 != k2) return false;

                    var u1 = existing.Unit?.Trim().ToLowerInvariant();
                    var u2 = cand.Unit?.Trim().ToLowerInvariant();
                    if (u1 != u2) return false;

                    return EquivalentMetricValue(existing.MetricValue, cand.MetricValue, existing.MetricKey ?? cand.MetricKey);
                }

                if (!existing.IsMetric && !cand.IsMetric)
                {
                    // Special-case: tax-only rows (TaxCollected / Itc) should dedupe based on TaxAmount alone.
                    var lt = (existing.LineType ?? string.Empty).Trim().ToLowerInvariant();
                    var ctLineType = (cand.LineType ?? string.Empty).Trim().ToLowerInvariant();

                    if ((lt == "taxcollected" || lt == "itc") && (ctLineType == "taxcollected" || ctLineType == "itc"))
                    {
                        var t1 = existing.TaxAmount ?? 0m;
                        var t2 = cand.TaxAmount ?? 0m;
                        return decimal.Round(t1, 2, MidpointRounding.AwayFromZero) == decimal.Round(t2, 2, MidpointRounding.AwayFromZero);
                    }

                    if (!string.Equals(existing.LineType, cand.LineType, StringComparison.OrdinalIgnoreCase)) return false;

                    var m1 = existing.MoneyAmount;
                    var m2 = cand.MoneyAmount;
                    if (m1.HasValue || m2.HasValue)
                    {
                        if (decimal.Round(m1 ?? 0m, 2, MidpointRounding.AwayFromZero) != decimal.Round(m2 ?? 0m, 2, MidpointRounding.AwayFromZero))
                            return false;
                    }

                    var tt1 = existing.TaxAmount;
                    var tt2 = cand.TaxAmount;
                    if (tt1.HasValue || tt2.HasValue)
                    {
                        if (decimal.Round(tt1 ?? 0m, 2, MidpointRounding.AwayFromZero) != decimal.Round(tt2 ?? 0m, 2, MidpointRounding.AwayFromZero))
                            return false;
                    }

                    return true;
                }

                return false;
            }

            foreach (var n in pruned)
            {
                // skip if an equivalent line was already added in this run
                if (createdLines.Any(e => IsEquivalent(e, n)))
                    continue;

                // normalize per-line currency (inherit statement if missing)
                var lineCurrency = n.CurrencyCode ?? statement.CurrencyCode;
                var lineCurrencyEvidence = n.CurrencyCode is null ? "Inferred" : n.CurrencyEvidence;

                // Start with collapsed canonical values (already normalized)
                decimal? moneyAmount = n.MoneyAmount;
                decimal? taxAmount = n.TaxAmount;

                // metrics: no money or tax
                if (n.IsMetric)
                {
                    moneyAmount = null;
                    taxAmount = null;
                }
                else
                {
                    // If both money and tax are missing/zero, it's an empty row — skip it.
                    // Keep tax-only rows (taxAmount > 0) and money rows (moneyAmount > 0).
                    var m = moneyAmount ?? 0m;
                    var t = taxAmount ?? 0m;
                    if (m == 0m && t == 0m)
                        continue;
                }

                var line = new StatementLine
                {
                    TenantId = tenantId,
                    StatementId = statement.Id,
                    LineDate = n.LineDate,

                    LineType = n.IsMetric ? "Metric" : n.LineType,
                    Description = n.Description,

                    CurrencyCode = lineCurrency,
                    CurrencyEvidence = lineCurrencyEvidence,

                    ClassificationEvidence = n.ClassificationEvidence,

                    IsMetric = n.IsMetric,
                    MetricKey = n.MetricKey,
                    MetricValue = n.MetricValue,
                    Unit = n.Unit,

                    MoneyAmount = moneyAmount,
                    TaxAmount = taxAmount
                };

                db.StatementLines.Add(line);
                createdLines.Add(line);
            }

            // compute rollups for event payload from persisted/normalized domain lines (post-normalization)
            var incomeTotal = createdLines.Where(x => x.LineType == "Income").Sum(x => x.MoneyAmount ?? 0m);
            var feeTotal = createdLines.Where(x => x.LineType == "Fee" || x.LineType == "Expense").Sum(x => x.MoneyAmount ?? 0m);
            var taxTotal = createdLines.Where(x => !x.IsMetric).Sum(x => x.TaxAmount ?? 0m);

            statement.StatementTotalAmount = incomeTotal - feeTotal; // simple net; adjust later if you want
            statement.TaxAmount = taxTotal;

            db.AuditEvents.Add(new AuditEvent
            {
                TenantId = tenantId,
                ActorUserId = "system",
                Action = "statement.parsed",
                EntityType = "Statement",
                EntityId = statement.Id.ToString("D"),
                OccurredAt = DateTimeOffset.UtcNow,
                CorrelationId = correlationId,
                MetadataJson = JsonSerializer.Serialize(new
                {
                    provider = statement.Provider,
                    periodType = statement.PeriodType,
                    periodKey = statement.PeriodKey,
                    lineCount = pruned.Count,
                    statementCurrency = statement.CurrencyCode,
                    currencyEvidence = statement.CurrencyEvidence,
                    modelVersion = extractor.ModelVersion
                }, JsonOpts)
            });

            db.Notifications.Add(new Notification
            {
                TenantId = tenantId,
                Type = "StatementParsed",
                Severity = "Info",
                Title = "Statement parsed",
                Body = $"Parsed {pruned.Count} lines ({statement.Provider} {statement.PeriodKey}).",
                DataJson = JsonSerializer.Serialize(new { statementId = statement.Id }, JsonOpts),
                Status = "New",
                CreatedAt = DateTimeOffset.UtcNow
            });

            await db.SaveChangesAsync(ct);

            // Publish StatementParsed (constructor signature matters!)
            var parsed = new StatementParsed(
                StatementId: statement.Id,
                TenantId: tenantId,
                Provider: statement.Provider,
                PeriodType: statement.PeriodType,
                PeriodKey: statement.PeriodKey,
                LineCount: pruned.Count,
                IncomeTotal: incomeTotal,
                FeeTotal: feeTotal,
                TaxTotal: taxTotal
            );


            var outEnvelope = new MessageEnvelope<StatementParsed>(
                MessageId: Guid.NewGuid().ToString("N"),
                Type: "statement.parsed.v1",
                OccurredAt: DateTimeOffset.UtcNow,
                TenantId: tenantId,
                CorrelationId: correlationId,
                Data: parsed
            );

            await publisher.PublishAsync("q.statement.parsed", outEnvelope, ct);
        }

        private static string ResolveStatementCurrency(
            FileObject file,
            IReadOnlyList<StatementLineNormalized> lines,
            out string evidence)
        {
            // 1) try from lines explicitly
            var explicitCur = lines
                .Select(x => x.CurrencyCode)
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .GroupBy(x => x!)
                .OrderByDescending(g => g.Count())
                .Select(g => g.Key)
                .FirstOrDefault();

            if (!string.IsNullOrWhiteSpace(explicitCur))
            {
                evidence = "Extracted";
                return explicitCur!;
            }

            // 2) Canada-first fallback
            evidence = "Inferred";
            return "CAD";
        }
    }
}
