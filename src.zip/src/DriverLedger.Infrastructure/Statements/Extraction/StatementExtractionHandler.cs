using DriverLedger.Application.Common;
using DriverLedger.Application.Messaging;
using DriverLedger.Application.Statements.Messages;
using DriverLedger.Domain.Auditing;
using DriverLedger.Domain.Notifications;
using DriverLedger.Domain.Ops;
using DriverLedger.Domain.Statements;
using DriverLedger.Infrastructure.Files;
using DriverLedger.Infrastructure.Messaging;
using DriverLedger.Infrastructure.Persistence;
using Microsoft.Extensions.Logging;
using System.Diagnostics;
using System.Text.Json;

namespace DriverLedger.Infrastructure.Statements.Extraction
{
    public sealed class StatementExtractionHandler(
        DriverLedgerDbContext db,
        ITenantProvider tenantProvider,
        IEnumerable<IStatementExtractor> extractors,
        IBlobStorage blobStorage,
        IMessagePublisher publisher,
        ILogger<StatementExtractionHandler> logger)
    {
        private static readonly JsonSerializerOptions JsonOpts = new(JsonSerializerDefaults.Web);

        private static bool IsUniqueViolation(DbUpdateException ex)
        {
            if (ex.InnerException is not Microsoft.Data.SqlClient.SqlException sql) return false;
            return sql.Number is 2601 or 2627;
        }

        public async Task HandleAsync(MessageEnvelope<StatementReceived> envelope, CancellationToken ct)
        {
            var tenantId = envelope.TenantId;
            var correlationId = envelope.CorrelationId;
            var payload = envelope.Data;

            tenantProvider.SetTenant(tenantId);

            using var scope = logger.BeginScope(new Dictionary<string, object?>
            {
                ["tenantId"] = tenantId,
                ["correlationId"] = correlationId,
                ["messageId"] = envelope.MessageId,
                ["statementId"] = payload.StatementId
            });

            var dedupeKey = $"statement.extract:{payload.StatementId}";

            var existingJob = await db.ProcessingJobs
                .SingleOrDefaultAsync(x => x.TenantId == tenantId && x.JobType == "statement.extract" && x.DedupeKey == dedupeKey, ct);

            if (existingJob is not null && existingJob.Status == "Succeeded")
            {
                logger.LogInformation("Extraction already succeeded. DedupeKey={DedupeKey}", dedupeKey);
                return;
            }

            ProcessingJob job;
            if (existingJob is null)
            {
                job = new()
                {
                    TenantId = tenantId,
                    JobType = "statement.extract",
                    DedupeKey = dedupeKey,
                    Status = "Started",
                    Attempts = 1,
                    CreatedAt = DateTimeOffset.UtcNow,
                    UpdatedAt = DateTimeOffset.UtcNow
                };
                db.ProcessingJobs.Add(job);
            }
            else
            {
                job = existingJob;
                job.Attempts += 1;
                job.Status = "Started";
                job.UpdatedAt = DateTimeOffset.UtcNow;
                job.LastError = null;
            }

            try
            {
                await db.SaveChangesAsync(ct);
            }
            catch (DbUpdateException ex) when (IsUniqueViolation(ex))
            {
                logger.LogWarning("ProcessingJob duplicate detected for dedupeKey={DedupeKey}. Reloading existing job.", dedupeKey);

                job = await db.ProcessingJobs
                    .SingleAsync(x => x.TenantId == tenantId && x.JobType == "statement.extract" && x.DedupeKey == dedupeKey, ct);

                job.Attempts += 1;
                job.Status = "Started";
                job.UpdatedAt = DateTimeOffset.UtcNow;
                job.LastError = null;

                await db.SaveChangesAsync(ct);
            }

            try
            {
                var statement = await db.Statements
                    .SingleAsync(x => x.TenantId == tenantId && x.Id == payload.StatementId, ct);

                var fileObj = await db.FileObjects
                    .SingleAsync(x => x.TenantId == tenantId && x.Id == payload.FileObjectId, ct);

                statement.Status = "Processing";
                await db.SaveChangesAsync(ct);

                var extractor = SelectExtractor(fileObj.ContentType);

                await using var remote = await blobStorage.OpenReadAsync(fileObj.BlobPath, ct);
                await using var ms = new MemoryStream();
                await remote.CopyToAsync(ms, ct);
                ms.Position = 0;

                var sw = Stopwatch.StartNew();
                var normalizedLines = await extractor.ExtractAsync(ms, ct);
                sw.Stop();

                var existingLines = await db.StatementLines
                    .Where(x => x.TenantId == tenantId && x.StatementId == statement.Id)
                    .ToListAsync(ct);

                if (existingLines.Count > 0)
                    db.StatementLines.RemoveRange(existingLines);

                var statementLines = normalizedLines
                .Select(line =>
                {
                    // If extractor produced a tax-only line as Amount (common in tables),
                    // move it into TaxAmount so it doesn't pollute income/expense totals.
                    var isTaxOnly = line.LineType is "TaxCollected" or "Itc" or "Tax";
                    var amount = line.Amount;
                    var taxAmount = line.TaxAmount;

                    if (isTaxOnly && (taxAmount is null || taxAmount == 0m) && amount != 0m)
                    {
                        taxAmount = amount;
                        amount = 0m;
                    }

                    return new StatementLine
                    {
                        TenantId = tenantId,
                        StatementId = statement.Id,
                        LineDate = line.LineDate == DateOnly.MinValue ? statement.PeriodStart : line.LineDate,
                        LineType = line.LineType,
                        Description = line.Description,
                        Currency = string.IsNullOrWhiteSpace(line.Currency)
                            ? (string.IsNullOrWhiteSpace(statement.Currency) ? "CAD" : statement.Currency)
                            : line.Currency,
                        Amount = amount,
                        TaxAmount = taxAmount
                    };
                })
                .ToList();

                // HOLD logic:
                // - 0 lines => nothing extracted
                // - OR lines exist but all numeric values are zero => extractor didn't actually parse amounts (common when PDF text is empty/image-only)
                var hasAnyNonZero = statementLines.Any(l =>
                    l.Amount != 0m || (l.TaxAmount.HasValue && l.TaxAmount.Value != 0m));

                if (statementLines.Count == 0 || !hasAnyNonZero)
                {
                    statement.Status = "HOLD";

                    // Avoid duplicate "New" holds for same statement
                    var hasActiveNotif = await db.Notifications.AnyAsync(x =>
                        x.TenantId == tenantId &&
                        x.Type == "StatementHold" &&
                        x.Status == "New" &&
                        x.DataJson.Contains(statement.Id.ToString("D")), ct);

                    if (!hasActiveNotif)
                    {
                        db.Notifications.Add(new Notification
                        {
                            TenantId = tenantId,
                            Type = "StatementHold",
                            Severity = "Warning",
                            Title = "Statement needs review",
                            Body = "We couldn't automatically extract amounts from this statement. Please review or re-upload a clearer statement.",
                            DataJson = JsonSerializer.Serialize(new { statementId = statement.Id }, JsonOpts),
                            Status = "New"
                        });
                    }

                    db.AuditEvents.Add(new AuditEvent
                    {
                        TenantId = tenantId,
                        ActorUserId = "system",
                        Action = "statement.hold",
                        EntityType = "Statement",
                        EntityId = statement.Id.ToString("D"),
                        OccurredAt = DateTimeOffset.UtcNow,
                        CorrelationId = correlationId,
                        MetadataJson = JsonSerializer.Serialize(new
                        {
                            reason = statementLines.Count == 0
                                ? "No statement lines detected from extractor output."
                                : "Statement lines detected, but all extracted numeric values were zero (likely image-only PDF or parsing mismatch).",
                            model = extractor.GetType().Name,
                            extractedLineCount = statementLines.Count,
                            extractedNonZero = hasAnyNonZero,
                            elapsedMs = sw.ElapsedMilliseconds
                        }, JsonOpts)
                    });

                    job.Status = "Succeeded"; // pipeline finished, but needs manual review
                    job.UpdatedAt = DateTimeOffset.UtcNow;

                    await db.SaveChangesAsync(ct);

                    logger.LogWarning(
                        "Statement extraction moved to HOLD. Lines={LineCount} HasAnyNonZero={HasAnyNonZero} ElapsedMs={ElapsedMs}",
                        statementLines.Count,
                        hasAnyNonZero,
                        sw.ElapsedMilliseconds);

                    return; // stop here - do NOT publish statement.parsed
                }

                // FIX: compute totals BEFORE using them
                var incomeTotal = statementLines.Where(x => x.LineType == "Income").Sum(x => x.Amount);
                var feeTotal = statementLines.Where(x => x.LineType == "Fee").Sum(x => x.Amount);

                var taxCollectedTotal = statementLines
                    .Where(x => x.LineType == "TaxCollected")
                    .Sum(x => x.TaxAmount ?? x.Amount);

                var itcTotal = statementLines
                    .Where(x => x.LineType == "Itc")
                    .Sum(x => x.TaxAmount ?? x.Amount);

                // taxTotal: keep old field meaning (optional)
                var taxTotal = taxCollectedTotal - itcTotal;

                // Persist best-effort statement totals
                var net = incomeTotal - feeTotal;

                // If the provider didn't give totals, store our computed totals.
                // Prefer net if it looks meaningful; otherwise store incomeTotal.
                if (statement.StatementTotalAmount is null)
                    statement.StatementTotalAmount = net != 0m ? net : incomeTotal;

                if (statement.TaxAmount is null && taxTotal != 0m)
                    statement.TaxAmount = taxTotal;

                // Fix legacy/provider disclaimer values if they slipped into Provider.
                if (!string.IsNullOrWhiteSpace(statement.Provider) &&
                    statement.Provider.Contains("NOT AN OFFICIAL", StringComparison.OrdinalIgnoreCase))
                {
                    var joined = string.Join(" ", statementLines.Select(l => l.Description ?? string.Empty));
                    if (joined.Contains("uber", StringComparison.OrdinalIgnoreCase)) statement.Provider = "Uber";
                    else if (joined.Contains("lyft", StringComparison.OrdinalIgnoreCase)) statement.Provider = "Lyft";
                }

                db.StatementLines.AddRange(statementLines);

                statement.Status = "Parsed";
                job.Status = "Succeeded";
                job.UpdatedAt = DateTimeOffset.UtcNow;

                await db.SaveChangesAsync(ct);

                logger.LogInformation(
                    "Statement parsed in {ElapsedMs}ms. Lines={LineCount} IncomeTotal={IncomeTotal} FeeTotal={FeeTotal} TaxTotal={TaxTotal}",
                    sw.ElapsedMilliseconds,
                    statementLines.Count,
                    incomeTotal,
                    feeTotal,
                    taxTotal);

                var parsedPayload = new StatementParsed(
                    StatementId: statement.Id,
                    TenantId: tenantId,
                    Provider: statement.Provider,
                    PeriodType: statement.PeriodType,
                    PeriodKey: statement.PeriodKey,
                    LineCount: statementLines.Count,
                    IncomeTotal: incomeTotal,
                    FeeTotal: feeTotal,
                    TaxTotal: taxTotal);

                var parsedEnvelope = new MessageEnvelope<StatementParsed>(
                    MessageId: Guid.NewGuid().ToString("N"),
                    Type: "statement.parsed.v1",
                    OccurredAt: DateTimeOffset.UtcNow,
                    TenantId: tenantId,
                    CorrelationId: correlationId,
                    Data: parsedPayload);

                await publisher.PublishAsync("q.statement.parsed", parsedEnvelope, ct);
            }
            catch (Exception ex)
            {
                job.Status = "Failed";
                job.LastError = ex.Message;
                job.UpdatedAt = DateTimeOffset.UtcNow;

                await db.SaveChangesAsync(ct);
                throw;
            }
        }

        private IStatementExtractor SelectExtractor(string contentType)
        {
            var extractor = extractors.FirstOrDefault(x => x.CanHandleContentType(contentType));
            if (extractor is null)
                throw new InvalidOperationException($"No statement extractor registered for content type '{contentType}'.");

            return extractor;
        }
    }
}
