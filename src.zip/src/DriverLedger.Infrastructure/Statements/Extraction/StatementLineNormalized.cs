namespace DriverLedger.Infrastructure.Statements.Extraction
{
    /// <summary>
    /// Normalized line output from statement extractors.
    /// Supports both monetary and non-posting metric lines (e.g., RideKilometers).
    /// </summary>
    public sealed record StatementLineNormalized(
        DateOnly LineDate,
        string LineType,
        string? Description,

        // New: metric support
        bool IsMetric,
        decimal? MoneyAmount,
        decimal? MetricValue,
        string? MetricKey,
        string? Unit,

        // New: currency normalization + evidence
        string? CurrencyCode,
        string CurrencyEvidence,

        // New: classification evidence
        string ClassificationEvidence,

        // Existing tax (kept)
        decimal? TaxAmount
    );
}
