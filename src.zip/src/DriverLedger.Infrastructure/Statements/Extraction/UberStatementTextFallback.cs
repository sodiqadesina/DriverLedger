using System.Text.RegularExpressions;

namespace DriverLedger.Infrastructure.Statements.Extraction;

internal static class UberStatementTextFallback
{
    // Extracts key Uber rows from analyzed.Content (full text).
    // Returns normalized lines with correct LineType + MoneyAmount/TaxAmount,
    // and emits ride distance as non-posting Metric lines (RideKilometers).
    public static List<StatementLineNormalized> TryExtract(string analyzedContent)
    {
        if (string.IsNullOrWhiteSpace(analyzedContent))
            return new List<StatementLineNormalized>();

        // Quick provider check
        if (!Regex.IsMatch(analyzedContent, @"\bUBER\b", RegexOptions.IgnoreCase))
            return new List<StatementLineNormalized>();

        var lines = analyzedContent
            .Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

        var results = new List<StatementLineNormalized>();

        // Helper: find a line containing label and parse the first numeric value on it
        static decimal? FindAmount(IEnumerable<string> src, string labelPattern)
        {
            foreach (var l in src)
            {
                if (!Regex.IsMatch(l, labelPattern, RegexOptions.IgnoreCase))
                    continue;

                var amt = StatementExtractionParsing.ParseAmount(l);
                if (amt.HasValue) return amt.Value;
            }
            return null;
        }

        // ====== Metrics (Ride Kilometers) ======
        // Uber statements differ, so we support a few common patterns.
        // Examples: "Online miles", "Online km", "Trip distance", "Total trip miles", etc.
        AddRideKilometersMetric(
            desc: "Ride kilometers",
            labelPattern: @"\b(ride|trip|total)\s*(kilometers|kilometres|kms|km)\b|\b(online|total)\s*km\b");

        // If Uber shows miles, we can store miles too OR convert to km. Here we convert to km and store RideKilometers.
        AddMilesAsKilometersMetric(
            desc: "Ride miles (converted to km)",
            labelPattern: @"\b(ride|trip|total)\s*(miles|mi)\b|\b(online|total)\s*miles\b");

        // ====== Monetary lines (Gross fares breakdown) ======
        AddIncome("Gross Uber rides fares", @"\bGross\s+Uber\s+rides\s+fares\b");
        AddIncome("Booking fee", @"\bBooking\s+fee\b");
        AddIncome("Regulatory Recovery Fees", @"\bRegulatory\s+Recovery\s+Fees\b");
        AddIncome("Airport fee", @"\bAirport\s+fee\b");
        AddIncome("Tips", @"\bTips\b(?!.*GST)", allowMultiple: false);

        // Tax collected from riders (TaxCollected)
        AddTaxCollected("GST/HST you collected from Riders", @"\bGST\s*/\s*HST\s+you\s+collected\s+from\s+Riders\b");

        // Fees (Fees breakdown)
        AddFee("Service Fee", @"\bService\s+Fee\b");
        AddFee("Other amounts", @"\bOther\s+amounts\b");
        AddFee("Fee Discount", @"\bFee\s+Discount\b", allowNegative: true);

        // ITC (tax you paid to Uber)
        AddItc("GST/HST you paid to Uber", @"\bGST\s*/\s*HST\s+you\s+paid\s+to\s+Uber\b");

        // Only return if we found something meaningful
        var anyNonZero = results.Any(x =>
            (x.MoneyAmount.HasValue && x.MoneyAmount.Value != 0m) ||
            (x.TaxAmount.HasValue && x.TaxAmount.Value != 0m) ||
            (x.IsMetric && x.MetricValue.HasValue && x.MetricValue.Value != 0m));

        return anyNonZero ? results : new List<StatementLineNormalized>();

        // ---- local helpers ----

        void AddIncome(string desc, string labelPattern, bool allowMultiple = false)
        {
            var amt = FindAmount(lines, labelPattern);
            if (!amt.HasValue) return;

            results.Add(new StatementLineNormalized(
                LineDate: DateOnly.MinValue,
                LineType: "Income",
                Description: desc,

                IsMetric: false,
                MoneyAmount: Math.Abs(amt.Value),
                MetricValue: null,
                MetricKey: null,
                Unit: null,

                CurrencyCode: "CAD",
                CurrencyEvidence: "Extracted",              // we are explicitly setting it
                ClassificationEvidence: "Extracted",        // label-driven fallback

                TaxAmount: null
            ));
        }

        void AddFee(string desc, string labelPattern, bool allowNegative = false)
        {
            var amt = FindAmount(lines, labelPattern);
            if (!amt.HasValue) return;

            var v = amt.Value;
            if (!allowNegative) v = Math.Abs(v);

            results.Add(new StatementLineNormalized(
                LineDate: DateOnly.MinValue,
                LineType: "Fee",
                Description: desc,

                IsMetric: false,
                MoneyAmount: Math.Abs(v),
                MetricValue: null,
                MetricKey: null,
                Unit: null,

                CurrencyCode: "CAD",
                CurrencyEvidence: "Extracted",
                ClassificationEvidence: "Extracted",

                TaxAmount: null
            ));
        }

        void AddTaxCollected(string desc, string labelPattern)
        {
            var amt = FindAmount(lines, labelPattern);
            if (!amt.HasValue) return;

            results.Add(new StatementLineNormalized(
                LineDate: DateOnly.MinValue,
                LineType: "TaxCollected",
                Description: desc,

                IsMetric: false,
                MoneyAmount: 0m, // monetary totals should ignore; tax goes in TaxAmount
                MetricValue: null,
                MetricKey: null,
                Unit: null,

                CurrencyCode: "CAD",
                CurrencyEvidence: "Extracted",
                ClassificationEvidence: "Extracted",

                TaxAmount: Math.Abs(amt.Value)
            ));
        }

        void AddItc(string desc, string labelPattern)
        {
            var amt = FindAmount(lines, labelPattern);
            if (!amt.HasValue) return;

            results.Add(new StatementLineNormalized(
                LineDate: DateOnly.MinValue,
                LineType: "Itc",
                Description: desc,

                IsMetric: false,
                MoneyAmount: 0m, // monetary totals should ignore; ITC tax goes in TaxAmount
                MetricValue: null,
                MetricKey: null,
                Unit: null,

                CurrencyCode: "CAD",
                CurrencyEvidence: "Extracted",
                ClassificationEvidence: "Extracted",

                TaxAmount: Math.Abs(amt.Value)
            ));
        }

        void AddRideKilometersMetric(string desc, string labelPattern)
        {
            var v = FindAmount(lines, labelPattern);
            if (!v.HasValue) return;

            results.Add(new StatementLineNormalized(
                LineDate: DateOnly.MinValue,
                LineType: "Metric",
                Description: desc,

                IsMetric: true,
                MoneyAmount: null,
                MetricValue: Math.Abs(v.Value),
                MetricKey: "RideKilometers",
                Unit: "km",

                CurrencyCode: null,
                CurrencyEvidence: "N/A",
                ClassificationEvidence: "Extracted",

                TaxAmount: null
            ));
        }

        void AddMilesAsKilometersMetric(string desc, string labelPattern)
        {
            var miles = FindAmount(lines, labelPattern);
            if (!miles.HasValue) return;

            // 1 mile = 1.609344 km
            var km = Math.Abs(miles.Value) * 1.609344m;

            results.Add(new StatementLineNormalized(
                LineDate: DateOnly.MinValue,
                LineType: "Metric",
                Description: desc,

                IsMetric: true,
                MoneyAmount: null,
                MetricValue: km,
                MetricKey: "RideKilometers",
                Unit: "km",

                CurrencyCode: null,
                CurrencyEvidence: "N/A",
                ClassificationEvidence: "Extracted",

                TaxAmount: null
            ));
        }
    }
}
